
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class Ground extends Scenery
{
    public Ground(int width, int height)
    {
        super(width, height);
    }
    public void act()
    {
        // Add your action code here.
    }
    
}

